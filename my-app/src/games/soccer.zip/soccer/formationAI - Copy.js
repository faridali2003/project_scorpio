import { attackingSign, MAX_JOG } from './pitchConstants';
import { defendLineY, getHalfL, getOriginX, getOriginY } from './playBounds';
import { ballSpeed } from './ballPhysics';
import { isBallDribbling } from './ballPossession';
import { applyPlayerMotor } from './playerKinematics';
import { clampOutfield } from './bounds';

export const AI_STATE = {
  HOLD: 'hold',
  CHASE: 'chase',
  PRESS: 'press',
};

function outfield(players, team) {
  return players.filter((p) => p.team === team && !p.isGk);
}

/** Formation slot with small shift toward ball — never full magnet. */
export function getFormationAnchor(p, ball) {
  const ox = getOriginX();
  const oy = getOriginY();
  const pull = p.role === 'fwd' ? 0.12 : p.role === 'mid' ? 0.08 : 0.04;
  return {
    x: p.homeX + (ball.x - p.homeX) * pull,
    y: p.homeY + (ball.y - p.homeY) * pull,
  };
}

function moveToward(p, tx, ty, sprint, dt) {
  const dx = tx - p.x;
  const dy = ty - p.y;
  const d = Math.hypot(dx, dy);
  if (d < 0.4) {
    p.vx *= 0.85;
    p.vy *= 0.85;
    return;
  }
  applyPlayerMotor(p, dx / d, dy / d, sprint, dt, { keepFacing: false });
  if (d > 0.6) p.facing = Math.atan2(dy, dx);
}

function applySeparation(p, players, team, dt) {
  players.forEach((o) => {
    if (o.id === p.id || o.isGk) return;
    const dx = p.x - o.x;
    const dy = p.y - o.y;
    const d = Math.hypot(dx, dy);
    const minD = o.team === team ? 2.0 : 1.3;
    if (d >= minD || d < 1e-4) return;
    const push = ((minD - d) / d) * 4.5 * dt;
    p.vx += dx * push;
    p.vy += dy * push;
  });
}

/**
 * Strict roles: ONE chaser on loose ball, ONE presser vs dribbler, everyone else holds shape.
 */
export function tickFormationAI(players, ball, team, dt, opts = {}) {
  const { skipControlled = true } = opts;
  const sign = attackingSign(team);
  const ox = getOriginX();
  const oy = getOriginY();
  const mates = outfield(players, team);

  const carrier = ball.possessionId != null
    ? players.find((pl) => pl.id === ball.possessionId)
    : null;
  const loose =
    !isBallDribbling(ball) && ballSpeed(ball) > 0.5 && ballSpeed(ball) < 16;
  const enemyDribble =
    isBallDribbling(ball) && carrier && carrier.team !== team;

  const sorted = [...mates].sort(
    (a, b) =>
      Math.hypot(a.x - ball.x, a.y - ball.y) - Math.hypot(b.x - ball.x, b.y - ball.y)
  );

  const chaserId = loose && sorted[0] ? sorted[0].id : null;
  let presserId = null;
  if (enemyDribble && sorted[0]) {
    presserId = sorted.find((p) => p.role === 'def' || p.role === 'mid')?.id ?? sorted[0].id;
  }

  const defendLine = defendLineY(team);

  mates.forEach((p) => {
    if (skipControlled && p.controlled) return;

    const dist = Math.hypot(p.x - ball.x, p.y - ball.y);
    let state = AI_STATE.HOLD;

    if (p.id === chaserId && dist < 28) {
      state = AI_STATE.CHASE;
    } else if (p.id === presserId && dist < 16) {
      state = AI_STATE.PRESS;
    }

    p.aiState = state;

    if (state === AI_STATE.CHASE) {
      moveToward(p, ball.x, ball.y, false, dt);
    } else if (state === AI_STATE.PRESS) {
      const laneX = ball.x + (ox - ball.x) * 0.15;
      const laneY = ball.y + (defendLine - ball.y) * 0.35;
      moveToward(p, laneX, laneY, true, dt);
    } else {
      const anchor = getFormationAnchor(p, ball);
      if (p.role === 'def') {
        anchor.y = anchor.y * 0.4 + (defendLine + sign * 5) * 0.6;
      }
      moveToward(p, anchor.x, anchor.y, false, dt);
    }

    applySeparation(p, players, team, dt);
    clampOutfield(p);
  });
}

import { attackingSign } from './pitchConstants';
import { clampGoalkeeper } from './bounds';
import { defendLineY, gkAnchorY, getOriginX } from './playBounds';

/** Keep GKs on the grass in front of the goal — never behind stadium walls. */
export function anchorGoalkeepers(players, ball, dt) {
  players.forEach((p) => {
    if (!p.isGk) return;

    const line = defendLineY(p.team);
    const sign = attackingSign(p.team);
    const anchor = gkAnchorY(p.team);
    const ox = getOriginX();

    p.homeX = ox;
    p.homeY = anchor;

    const trackX = Math.max(-8, Math.min(8, ball.x - ox));
    const ballThreat = sign * (ball.y - line) > 1;
    const ballNear = Math.hypot(p.x - ball.x, p.y - ball.y) < 22;

    if (ballThreat && ballNear) {
      p.x += (ox + trackX * 0.35 - p.x) * Math.min(1, dt * 5);
      const stepY = sign * Math.min(2, Math.max(0, sign * (ball.y - anchor) * 0.12));
      const targetY = anchor + stepY;
      p.y += (targetY - p.y) * Math.min(1, dt * 4);
    } else {
      p.x += (ox - p.x) * Math.min(1, dt * 4);
      p.y += (anchor - p.y) * Math.min(1, dt * 5);
    }

    const nearLine = line + sign * 1.1;
    const deepIn = line + sign * 6.5;
    if (sign > 0) {
      p.y = Math.max(nearLine, Math.min(deepIn, p.y));
    } else {
      p.y = Math.min(nearLine, Math.max(deepIn, p.y));
    }

    clampGoalkeeper(p);
    p.facing = Math.atan2(sign, 0);
  });
}

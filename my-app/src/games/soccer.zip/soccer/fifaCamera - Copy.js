import * as THREE from 'three';
import { attackingSign, TEAM_HOME } from './pitchConstants';

/**
 * FIFA gameplay camera — stable bearing (does not whip with every step).
 * Movement uses camYaw, not the live camera matrix (avoids feedback jitter).
 */
export function createFifaCameraState() {
  return { camYaw: Math.PI / 2 };
}

function lerpAngle(a, b, t) {
  let d = b - a;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  return a + d * t;
}

function clampTurn(current, target, maxStep) {
  let d = target - current;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  if (Math.abs(d) <= maxStep) return target;
  return current + Math.sign(d) * maxStep;
}

export function getCameraYaw(state) {
  return state.camYaw ?? Math.PI / 2;
}

/** Standard Gamepad API: axis 0 = LS X, axis 1 = LS Y (up often negative). */
export function readGamepadSticks(pad) {
  const move = readPair(pad, 0, 1);
  const cam = readPair(pad, 2, 3);
  return {
    move,
    cam,
    moveMag: Math.hypot(move.x, move.y),
    camMag: Math.hypot(cam.x, cam.y),
  };
}

function readPair(pad, ax, ay) {
  const DEAD = 0.14;
  const dz = (v) => {
    const a = Math.abs(v);
    if (a < DEAD) return 0;
    return (Math.sign(v) * (a - DEAD)) / (1 - DEAD);
  };
  let x = dz(pad.axes[ax] ?? 0);
  let y = dz(-(pad.axes[ay] ?? 0));
  const len = Math.hypot(x, y);
  if (len > 1) {
    x /= len;
    y /= len;
  }
  return { x, y };
}

/**
 * LS move on pitch (x, y) relative to fixed camera yaw — stick up = into screen.
 */
export function movementFromCameraYaw(camYaw, stickX, stickY) {
  const len = Math.hypot(stickX, stickY);
  if (len < 0.02) return { x: 0, y: 0 };

  const nx = stickX / len;
  const ny = stickY / len;
  const cos = Math.cos(camYaw);
  const sin = Math.sin(camYaw);
  const fwdX = cos;
  const fwdY = sin;
  const rightX = -sin;
  const rightY = cos;

  return {
    x: rightX * nx + fwdX * ny,
    y: rightY * nx + fwdY * ny,
  };
}

const BEHIND = 18;
const HEIGHT = 12.5;
const LOOK_AHEAD = 9;
const MAX_YAW_RATE = 1.05;
const POS_SMOOTH = 4.5;

export function updateFifaCamera(camera, state, player, ball, dt, team = TEAM_HOME) {
  if (!player) {
    const yaw = Math.atan2(ball.y, ball.x + 0.001);
    state.camYaw = yaw;
    applyCameraPose(camera, ball.x, ball.y, yaw, dt, 0.6);
    return;
  }

  const sign = attackingSign(team);
  const attackYaw = Math.atan2(sign, 0);
  const ballDist = Math.hypot(ball.x - player.x, ball.y - player.y);
  const toBall = Math.atan2(ball.y - player.y, ball.x - player.x);

  let targetYaw = attackYaw;
  if (ballDist < 32) {
    const blend = Math.min(0.62, (32 - ballDist) / 32);
    targetYaw = lerpAngle(attackYaw, toBall, blend);
  }

  const yaw0 = state.camYaw ?? targetYaw;
  state.camYaw = clampTurn(yaw0, targetYaw, MAX_YAW_RATE * dt);

  const focusT = ballDist < 40 ? 0.28 : 0.12;
  const fx = player.x * (1 - focusT) + ball.x * focusT;
  const fz = player.y * (1 - focusT) + ball.y * focusT;

  applyCameraPose(camera, fx, fz, state.camYaw, dt, 1);
}

function applyCameraPose(camera, fx, fz, yaw, dt, smoothMul) {
  const cos = Math.cos(yaw);
  const sin = Math.sin(yaw);
  const desired = new THREE.Vector3(fx - cos * BEHIND, HEIGHT, fz - sin * BEHIND);
  const k = (1 - Math.exp(-POS_SMOOTH * dt)) * smoothMul;
  camera.position.lerp(desired, k);
  camera.lookAt(fx + cos * LOOK_AHEAD, 1.25, fz + sin * LOOK_AHEAD);
}

export function menuBroadcastCamera(camera, dt) {
  const desired = new THREE.Vector3(0, 58, 88);
  camera.position.lerp(desired, 1 - Math.exp(-3 * dt));
  camera.lookAt(0, 0, 0);
}

import * as THREE from 'three';
import {
  GOAL_WIDTH,
  GOAL_HEIGHT,
  GOAL_DEPTH,
  TEAM_HOME,
  TEAM_AWAY,
} from './pitchConstants';
import { defendLineY, getOriginX } from './playBounds';

const POST_R = 0.12;
const POST_MAT = new THREE.MeshBasicMaterial({ color: 0xffffff });
const NET_MAT = new THREE.MeshBasicMaterial({
  color: 0xdddddd,
  transparent: true,
  opacity: 0.55,
  side: THREE.DoubleSide,
  depthWrite: false,
});

function buildOneGoal(defendTeam) {
  const goal = new THREE.Group();
  goal.name = defendTeam === TEAM_HOME ? 'ScorpioGoal_Home' : 'ScorpioGoal_Away';
  goal.userData.defendTeam = defendTeam;

  const hw = GOAL_WIDTH / 2;
  const h = GOAL_HEIGHT;
  const baseY = 0.06;

  const postGeo = new THREE.CylinderGeometry(POST_R, POST_R, h, 12);
  const left = new THREE.Mesh(postGeo, POST_MAT);
  left.name = 'ScorpioGoal_Post';
  left.position.set(-hw, baseY + h / 2, 0);
  const right = new THREE.Mesh(postGeo, POST_MAT);
  right.name = 'ScorpioGoal_Post';
  right.position.set(hw, baseY + h / 2, 0);

  const bar = new THREE.Mesh(
    new THREE.CylinderGeometry(POST_R, POST_R, GOAL_WIDTH + POST_R * 2, 12),
    POST_MAT
  );
  bar.name = 'ScorpioGoal_Bar';
  bar.rotation.z = Math.PI / 2;
  bar.position.set(0, baseY + h, 0);

  const net = new THREE.Mesh(
    new THREE.BoxGeometry(GOAL_WIDTH, h * 0.95, GOAL_DEPTH),
    NET_MAT
  );
  net.name = 'ScorpioGoal_Net';

  const sign = defendTeam === TEAM_HOME ? 1 : -1;
  net.position.set(0, baseY + h * 0.48, -sign * (GOAL_DEPTH / 2 + 0.05));

  const frame = new THREE.LineSegments(
    new THREE.EdgesGeometry(new THREE.BoxGeometry(GOAL_WIDTH, h, GOAL_DEPTH)),
    new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.85 })
  );
  frame.name = 'ScorpioGoal_Frame';
  frame.position.copy(net.position);

  goal.add(left, right, bar, net, frame);
  goal.traverse((c) => {
    if (c.isMesh) {
      c.renderOrder = 20;
      c.castShadow = true;
    }
    if (c.isLineSegments) c.renderOrder = 21;
  });
  return goal;
}

/** FIFA goals — always visible, aligned to play bounds. */
export function createMatchGoals() {
  const group = new THREE.Group();
  group.name = 'MatchGoals';
  group.add(buildOneGoal(TEAM_HOME), buildOneGoal(TEAM_AWAY));
  syncMatchGoals(group);
  return group;
}

export function syncMatchGoals(group) {
  if (!group) return;
  const ox = getOriginX();
  group.children.forEach((goal) => {
    const team = goal.userData.defendTeam;
    const line = defendLineY(team);
    const sign = team === TEAM_HOME ? 1 : -1;
    goal.position.set(ox, 0, line);
    goal.rotation.y = sign > 0 ? 0 : Math.PI;
    goal.visible = true;
  });
  group.visible = true;
}

import { getHalfW, getHalfL, getOriginX, getOriginY } from './playBounds';
import { syncHumanoid } from './matchVisuals';

/** Referee jogs along the touchline nearest the ball (same coords as players). */
export function updateReferee(referee, ball, dt) {
  if (!referee) return;

  const ox = getOriginX();
  const oy = getOriginY();
  const hw = getHalfW() + 1.2;
  const hl = getHalfL();

  const onRight = ball.x - ox > 0;
  const tx = ox + (onRight ? hw : -hw);
  const ty = Math.max(oy - hl + 5, Math.min(oy + hl - 5, ball.y));
  const facing = onRight ? -Math.PI / 2 : Math.PI / 2;

  const rx = referee.userData.rx ?? tx;
  const ry = referee.userData.ry ?? ty;
  const nx = rx + (tx - rx) * Math.min(1, dt * 5);
  const ny = ry + (ty - ry) * Math.min(1, dt * 5);
  referee.userData.rx = nx;
  referee.userData.ry = ny;

  syncHumanoid(referee, nx, ny, facing, false);
}

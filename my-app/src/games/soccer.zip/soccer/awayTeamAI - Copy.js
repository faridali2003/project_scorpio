import { TEAM_AWAY, attackingSign, MAX_JOG } from './pitchConstants';
import { kickBall, ballSpeed } from './ballPhysics';
import { isBallDribbling } from './ballPossession';
import { tickTeamMovement, chaseBall } from './teamMovement';
import { aiKickDecision, nearestToBall } from './players';

let kickCooldown = 0;

export function resetAwayTeamAI() {
  kickCooldown = 0;
}

export function tickAwayTeamAI(players, ball, match, dt) {
  kickCooldown = Math.max(0, kickCooldown - dt);

  tickTeamMovement(players, ball, TEAM_AWAY, dt, {
    skipControlled: false,
    pressFactor: 0.55,
    maxChasers: 1,
  });

  if (isBallDribbling(ball)) return;

  const outfield = players.filter((p) => p.team === TEAM_AWAY && !p.isGk);
  const opponents = players.filter((p) => p.team !== TEAM_AWAY);
  const chaser = nearestToBall(outfield, TEAM_AWAY, ball);
  if (!chaser) return;

  const chaserDist = Math.hypot(chaser.x - ball.x, chaser.y - ball.y);
  if (chaserDist > 1.35 || ballSpeed(ball) > 1.2 || kickCooldown > 0) return;

  const act = aiKickDecision(chaser, ball, outfield, opponents);
  if (!act) return;

  kickCooldown = 0.8;
  const sign = attackingSign(TEAM_AWAY);
  if (act.type === 'shoot') {
    kickBall(ball, 0, sign, act.power, { lift: act.lift ?? 2.5 });
  } else if (act.type === 'pass' && act.target) {
    kickBall(ball, act.target.x - chaser.x, act.target.y - chaser.y, act.power, { lift: act.lift ?? 0 });
  }
  match.lastTouchTeam = TEAM_AWAY;
}

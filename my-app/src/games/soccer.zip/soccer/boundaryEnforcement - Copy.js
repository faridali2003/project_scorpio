import { detectBoundaryEvents } from './goalDetection';
import { isInsidePitch, toLocal, getHalfW, getHalfL } from './playBounds';

/** True when ball centre is over the touchline / goal line (white line). */
export function isBallOutOfPlay(ball, margin = 0.05) {
  const l = toLocal(ball.x, ball.y);
  const hw = getHalfW() - margin;
  const hl = getHalfL() - margin;
  return Math.abs(l.x) > hw || Math.abs(l.y) > hl;
}

/**
 * Run line detection even when dribbling / player carried ball past line.
 * Returns same shape as detectBoundaryEvents.
 */
export function checkPlayBoundary(ball, prevBall, match) {
  if (match.phase !== 'play') {
    return { goal: null, out: null };
  }
  return detectBoundaryEvents(ball, prevBall, match.lastTouchTeam);
}

export function clampBallToPitch(ball) {
  const l = toLocal(ball.x, ball.y);
  const hw = getHalfW() - 0.2;
  const hl = getHalfL() - 0.2;
  if (Math.abs(l.x) <= hw && Math.abs(l.y) <= hl) return;
  const ox = ball.x - l.x;
  const oy = ball.y - l.y;
  const cx = Math.max(-hw, Math.min(hw, l.x));
  const cy = Math.max(-hl, Math.min(hl, l.y));
  ball.x = ox + cx;
  ball.y = oy + cy;
}

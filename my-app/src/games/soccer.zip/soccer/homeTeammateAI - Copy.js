import { TEAM_HOME, attackingSign } from './pitchConstants';
import { kickBall, ballSpeed } from './ballPhysics';
import { isBallDribbling } from './ballPossession';
import { tickTeamMovement, chaseBall } from './teamMovement';

let passCooldown = 0;

export function resetHomeTeammateAI() {
  passCooldown = 0;
}

export function tickHomeTeammateAI(players, ball, match, dt) {
  passCooldown = Math.max(0, passCooldown - dt);

  tickTeamMovement(players, ball, TEAM_HOME, dt, {
    skipControlled: true,
    pressFactor: 0.85,
    maxChasers: 2,
  });

  if (match.passSwitchToId != null) {
    const recv = players.find((p) => p.id === match.passSwitchToId);
    if (recv && !recv.controlled) {
      chaseBall(recv, ball, dt, 1.5);
    }
    return;
  }

  if (isBallDribbling(ball)) return;

  const outfield = players.filter((p) => p.team === TEAM_HOME && !p.isGk && !p.controlled);
  let ballCarrier = null;
  let carrierDist = Infinity;
  outfield.forEach((p) => {
    const d = Math.hypot(p.x - ball.x, p.y - ball.y);
    if (d < carrierDist) {
      carrierDist = d;
      ballCarrier = p;
    }
  });

  if (!ballCarrier || carrierDist > 1.3 || ballSpeed(ball) > 2.5) return;

  const sign = attackingSign(TEAM_HOME);

  if (passCooldown <= 0 && ballSpeed(ball) < 1.2) {
    const mates = outfield.filter((m) => m.id !== ballCarrier.id);
    const target = mates.sort((a, b) => sign * (b.y - a.y))[0];
    if (target && Math.hypot(target.x - ballCarrier.x, target.y - ballCarrier.y) > 8) {
      kickBall(ball, target.x - ballCarrier.x, target.y - ballCarrier.y, 10, { lift: 0 });
      match.lastTouchTeam = TEAM_HOME;
      passCooldown = 1.5;
    }
  }
}

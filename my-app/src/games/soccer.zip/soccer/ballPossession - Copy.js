import { BALL_RADIUS } from './pitchConstants';
import { ballSpeed } from './ballPhysics';
import { clearGuidedShot } from './guidedShot';

const DRIBBLE_TOUCH = 1.42;
const DRIBBLE_LEAD = 0.58;
const TACKLE_DIST = 1.15;
const TACKLE_SPEED = 2.8;
const LOOSE_BALL_SPEED = 17;

export function clearBallPossession(ball) {
  ball.possessionId = null;
  ball._kickCooldown = 0;
}

export function markBallKicked(ball) {
  ball.possessionId = null;
  ball._kickCooldown = 0.22;
}

export function isBallDribbling(ball) {
  return (
    ball.possessionId != null &&
    ball.z <= BALL_RADIUS + 0.3 &&
    ballSpeed(ball) < 12
  );
}

/** Stable touch-and-chase — ball leads player slightly, no velocity explosions. */
function applyDribbleTouch(ball, carrier, dt) {
  const f = carrier.facing;
  const tx = carrier.x + Math.cos(f) * DRIBBLE_LEAD;
  const ty = carrier.y + Math.sin(f) * DRIBBLE_LEAD;

  const blend = Math.min(1, 14 * dt);
  ball.x += (tx - ball.x) * blend;
  ball.y += (ty - ball.y) * blend;

  const cSpd = Math.hypot(carrier.vx, carrier.vy);
  const ahead = 1.65 + cSpd * 0.32;
  ball.vx = carrier.vx * 0.78 + Math.cos(f) * ahead;
  ball.vy = carrier.vy * 0.78 + Math.sin(f) * ahead;
  ball.z = BALL_RADIUS;
  ball.vz = 0;

  if (Math.hypot(ball.x - carrier.x, ball.y - carrier.y) > DRIBBLE_TOUCH + 0.55) {
    ball.possessionId = null;
  }
}

export function updateBallPossession(ball, players, match, dt) {
  if (ball._kickCooldown > 0) {
    ball._kickCooldown -= dt;
    ball.possessionId = null;
    if (match.passSwitchToId != null) {
      const recv = players.find((p) => p.id === match.passSwitchToId);
      if (recv && Math.hypot(recv.x - ball.x, recv.y - ball.y) < 2.5) {
        ball.possessionId = recv.id;
        applyDribbleTouch(ball, recv, dt);
      }
    }
    return;
  }

  if (ball.guided && ballSpeed(ball) > 8) return;

  if (ball.z > 1.6 || ballSpeed(ball) > LOOSE_BALL_SPEED) {
    ball.possessionId = null;
    return;
  }

  let carrier = ball.possessionId != null
    ? players.find((p) => p.id === ball.possessionId)
    : null;

  if (carrier) {
    const d = Math.hypot(carrier.x - ball.x, carrier.y - ball.y);
    if (d > DRIBBLE_TOUCH + 0.45) {
      ball.possessionId = null;
      carrier = null;
    }
  }

  if (!carrier) {
    let bestD = DRIBBLE_TOUCH;
    players.forEach((p) => {
      const dist = Math.hypot(p.x - ball.x, p.y - ball.y);
      if (dist < bestD) {
        bestD = dist;
        carrier = p;
      }
    });
  }

  if (carrier) {
    const opps = players.filter((o) => o.team !== carrier.team);
    for (let i = 0; i < opps.length; i += 1) {
      const o = opps[i];
      const d = Math.hypot(o.x - ball.x, o.y - ball.y);
      const oSpd = Math.hypot(o.vx, o.vy);
      if (d < TACKLE_DIST && oSpd > TACKLE_SPEED) {
        ball.possessionId = null;
        ball.vx = o.vx * 0.65 + (ball.x - o.x) * 1.5;
        ball.vy = o.vy * 0.65 + (ball.y - o.y) * 1.5;
        match.lastTouchTeam = o.team;
        clearGuidedShot(ball);
        return;
      }
    }
  }

  if (!carrier) {
    ball.possessionId = null;
    return;
  }

  ball.possessionId = carrier.id;
  match.lastTouchTeam = carrier.team;
  applyDribbleTouch(ball, carrier, dt);
}

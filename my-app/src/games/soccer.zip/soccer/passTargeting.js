import { attackingSign } from './pitchConstants';

/** Aim vector for pass: LS / stick if held, else player facing. */
export function getPassAimDirection(active, aimX = 0, aimY = 0) {
  const len = Math.hypot(aimX, aimY);
  if (len > 0.22) {
    return { x: aimX / len, y: aimY / len };
  }
  return { x: Math.cos(active.facing), y: Math.sin(active.facing) };
}

/**
 * Pick pass receiver by aim cone + distance — not nearest to the ball.
 * Hold LB (driven) or Y (through) to bias longer / more forward targets.
 */
export function findPassTarget(mates, active, opponents, aim, opts = {}) {
  const { driven = false, through = false, minDist = 2.8 } = opts;
  const sign = attackingSign(active.team);
  const idealDist = through ? 22 : driven ? 16 : 11;

  let best = null;
  let bestScore = -Infinity;

  mates.forEach((m) => {
    const dx = m.x - active.x;
    const dy = m.y - active.y;
    const dist = Math.hypot(dx, dy);
    if (dist < minDist) return;

    const dirX = dx / dist;
    const dirY = dy / dist;
    const align = dirX * aim.x + dirY * aim.y;
    const minAlign = through ? 0.35 : driven ? 0.2 : 0.12;
    if (align < minAlign) return;

    const forward = sign * (m.y - active.y);
    if (through && forward < 6) return;

    let openMin = 99;
    opponents.forEach((o) => {
      openMin = Math.min(openMin, Math.hypot(o.x - m.x, o.y - m.y));
    });
    const openScore = Math.min(openMin, 14) * 0.28;

    const forwardScore = through
      ? forward * 0.14
      : driven
        ? forward * 0.09
        : Math.min(Math.max(forward, 0), 28) * 0.07;

    const distScore = -Math.abs(dist - idealDist) * (through ? 0.06 : 0.1);
    const alignScore = align * (through ? 6 : driven ? 5 : 4.5);

    const score = alignScore + forwardScore + openScore + distScore;
    if (score > bestScore) {
      bestScore = score;
      best = m;
    }
  });

  if (best) return best;

  let fallback = null;
  let fbScore = -Infinity;
  mates.forEach((m) => {
    const dx = m.x - active.x;
    const dy = m.y - active.y;
    const dist = Math.hypot(dx, dy);
    if (dist < 1.5) return;
    const align = (dx / dist) * aim.x + (dy / dist) * aim.y;
    const forward = sign * (m.y - active.y);
    const score = align * 3 + forward * 0.08 - dist * 0.02;
    if (score > fbScore) {
      fbScore = score;
      fallback = m;
    }
  });

  return fallback || mates[0] || null;
}

export function passPowerForDistance(dist, driven, through) {
  if (through) return 12.5 + dist * 0.24;
  if (driven) return 11.5 + dist * 0.2;
  return 9.5 + dist * 0.16;
}

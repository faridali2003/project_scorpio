import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { PITCH_WIDTH, PITCH_LENGTH } from './pitchConstants';
import { lockFifaPlayBounds } from './playBounds';
import { buildPitchWorld, getPitchWorldBounds } from './pitchWorld';
import { createLinesOverlay, createRuntimeGoals } from './pitchOverlay';
import {
  hideStaticStadiumActors,
  hidePitchClutterMeshes,
  findStadiumBallTemplate,
  fixGrassStripeSeams,
  fixPitchMarkingZFight,
} from './stadiumActors';

const STADIUM_URL = '/games/soccer/stadium.glb';
const LOAD_TIMEOUT_MS = 8000;

const _box = new THREE.Box3();
const _size = new THREE.Vector3();
const _center = new THREE.Vector3();

function stadiumAssetUrl() {
  const base = process.env.PUBLIC_URL || '';
  return `${base}${STADIUM_URL}`;
}

function measurePlayableTurf(root) {
  const box = new THREE.Box3();
  let hit = false;
  root.traverse((o) => {
    if (!o.isMesh) return;
    const n = o.name || '';
    if (/^Grass|^Pitch|^Turf|^Field|^Ground/i.test(n)) {
      box.expandByObject(o);
      hit = true;
    }
  });
  return hit ? box : null;
}

function fitStadiumToPitch(root) {
  const turf = measurePlayableTurf(root);
  const fit = turf || (() => {
    _box.setFromObject(root);
    return _box;
  })();

  fit.getSize(_size);
  const sx = PITCH_WIDTH / Math.max(_size.x, 1);
  const sz = PITCH_LENGTH / Math.max(_size.z, 1);
  root.scale.multiply(new THREE.Vector3(sx, 1, sz));
  root.updateMatrixWorld(true);

  _box.setFromObject(root);
  _box.getCenter(_center);
  root.position.x -= _center.x;
  root.position.z -= _center.z;
  root.updateMatrixWorld(true);

  _box.setFromObject(root);
  root.position.y -= _box.min.y;
  root.updateMatrixWorld(true);
}

function loadGltfWithTimeout(url) {
  return new Promise((resolve, reject) => {
    const loader = new GLTFLoader();
    let done = false;
    const timer = setTimeout(() => {
      if (done) return;
      done = true;
      reject(new Error('stadium load timeout'));
    }, LOAD_TIMEOUT_MS);

    loader.load(
      url,
      (gltf) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        resolve(gltf);
      },
      undefined,
      (err) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        reject(err);
      }
    );
  });
}

function finishGlbStadium(root) {
  root.traverse((child) => {
    if (child.isMesh) {
      child.castShadow = false;
      child.receiveShadow = true;
    }
  });
  fitStadiumToPitch(root);
  hideStaticStadiumActors(root);
  hidePitchClutterMeshes(root);
  fixGrassStripeSeams(root);
  fixPitchMarkingZFight(root);
}

function addGameplayLayers(scene) {
  const layer = new THREE.Group();
  layer.name = 'GameplayOverlay';
  layer.add(createLinesOverlay());
  layer.add(createRuntimeGoals());
  scene.add(layer);
  return layer;
}

/** Blender stadium.glb + lines + single goal pair. */
export function loadStadiumGlb(scene) {
  lockFifaPlayBounds();
  const overlay = addGameplayLayers(scene);

  const url = stadiumAssetUrl();
  return loadGltfWithTimeout(url)
    .then((gltf) => {
      const root = gltf.scene;
      root.name = 'StadiumGLB';
      scene.add(root);
      finishGlbStadium(root);
      const ballTemplate = findStadiumBallTemplate(root);
      console.info('[Scorpio Soccer] stadium.glb loaded');
      return {
        root,
        overlay,
        bounds: getPitchWorldBounds(),
        ballTemplate,
        fallback: false,
      };
    })
    .catch((err) => {
      console.warn('[Scorpio Soccer] GLB failed, built-in pitch:', err?.message || err);
      scene.remove(overlay);
      const root = buildPitchWorld();
      scene.add(root);
      return {
        root,
        overlay: null,
        bounds: getPitchWorldBounds(),
        ballTemplate: null,
        fallback: true,
      };
    });
}

export function getStadiumFog(bounds) {
  const extent = Math.max(bounds?.width ?? 120, bounds?.length ?? 160, 120);
  return {
    color: 0x87b8d8,
    near: 100,
    far: extent * 2.8,
    cameraFar: Math.max(450, extent * 4),
  };
}

import { formatClock } from './matchRules';

export default function SoccerHud({
  phase,
  match,
  hudTick,
  usingGamepad,
  lightingMode,
  stadiumReady = true,
  loadError = null,
  controlHintText = '',
  showInputDebugHint = false,
  onStart,
  onExit,
  onPause,
}) {
  const playing = phase === 'playing' || phase === 'paused';
  void hudTick;

  return (
    <div className="scorpio-soccer__hud">
      {playing && (
        <>
          <div className="scorpio-soccer__scoreboard">
            <span className="scorpio-soccer__team scorpio-soccer__team--home">HOME</span>
            <span className="scorpio-soccer__score">
              {match.homeScore} — {match.awayScore}
            </span>
            <span className="scorpio-soccer__team scorpio-soccer__team--away">AWAY</span>
          </div>
          <div className="scorpio-soccer__match-bar">
            <span className="scorpio-soccer__clock">
              {formatClock(match.clockSec)} · {match.half === 1 ? '1st half' : '2nd half'}
            </span>
            <span className="scorpio-soccer__possession">7v7</span>
            <span className={`scorpio-soccer__light scorpio-soccer__light--${lightingMode}`}>
              {lightingMode === 'night' ? 'Night' : 'Day'}
            </span>
          </div>
          {(match.message || match.phase !== 'play') && (
            <div className="scorpio-soccer__banner">
              {match.message || match.phase.replace(/_/g, ' ')}
              {match.phaseTimer > 0 && match.phase !== 'play'
                ? ` (${Math.ceil(match.phaseTimer)}s)`
                : ''}
            </div>
          )}
          <div className="scorpio-soccer__hint">{controlHintText}</div>
          <div className="scorpio-soccer__ref-badge">Referee on touchline</div>
        </>
      )}

      {phase === 'menu' && (
        <div className="scorpio-soccer__menu">
          <h1>Scorpio Soccer</h1>
          <p>FIFA controls · ground.glb stadium · 7v7 · referee &amp; match clock</p>
          {showInputDebugHint ? (
            <p className="scorpio-soccer__menu-sub scorpio-soccer__menu-debug">
              Screen recording / QA: press <strong>F3</strong> during a match for the input overlay.
              Or open with <strong>?soccerDebug=1</strong> (starts visible).
            </p>
          ) : null}
          <div className="scorpio-soccer__controls-guide">
            <h3>Xbox layout</h3>
            <ul>
              <li><strong>LS</strong> Move · <strong>RB</strong> Switch (nearest to ball)</li>
              <li><strong>RT</strong> Sprint · <strong>LT</strong> Jockey / contain</li>
              <li><strong>A</strong> Pass · <strong>B</strong> Shoot · <strong>Y</strong> Through ball</li>
              <li><strong>X</strong> Lob · <strong>LB</strong> + A driven pass · <strong>LB</strong> + B finesse shot</li>
              <li><strong>D-pad</strong> Tactics · <strong>Menu</strong> Pause</li>
            </ul>
          </div>
          {loadError && (
            <p className="scorpio-soccer__menu-error">Note: {loadError}</p>
          )}
          <div className="scorpio-soccer__menu-actions">
            <button
              type="button"
              className="btn btn-primary btn-lg"
              onClick={onStart}
              disabled={!stadiumReady}
            >
              {stadiumReady ? 'Kick off' : 'Loading stadium…'}
            </button>
            {onExit ? (
              <button type="button" className="btn btn-secondary" onClick={onExit}>
                Back to store
              </button>
            ) : null}
          </div>
        </div>
      )}

      {phase === 'paused' && (
        <div className="scorpio-soccer__menu scorpio-soccer__menu--overlay">
          <h2>Paused</h2>
          <div className="scorpio-soccer__menu-actions">
            <button type="button" className="btn btn-primary" onClick={onPause}>
              Resume
            </button>
            {onExit ? (
              <button type="button" className="btn btn-secondary" onClick={onExit}>
                Quit
              </button>
            ) : null}
          </div>
        </div>
      )}

      {phase === 'fulltime' && (
        <div className="scorpio-soccer__menu scorpio-soccer__menu--overlay">
          <h2>Full time</h2>
          <p className="scorpio-soccer__final">
            {match.homeScore} — {match.awayScore}
          </p>
          <div className="scorpio-soccer__menu-actions">
            <button type="button" className="btn btn-primary" onClick={onStart}>
              Rematch
            </button>
            {onExit ? (
              <button type="button" className="btn btn-secondary" onClick={onExit}>
                Back to store
              </button>
            ) : null}
          </div>
        </div>
      )}
    </div>
  );
}

import { TEAM_HOME, TEAM_AWAY, attackingSign, MAX_SPRINT } from './pitchConstants';
import { ballSpeed } from './ballPhysics';
import { isBallDribbling } from './ballPossession';
import { kickBall } from './ballPhysics';
import { aiKickDecision, nearestToBall } from './players';
import { tickFormationAI } from './formationAI';
import { chaseBall } from './teamMovement';

let awayKickCd = 0;
let homeCpuPassCd = 0;

export function resetSoccerAI() {
  awayKickCd = 0;
  homeCpuPassCd = 0;
}

function outfield(players, team) {
  return players.filter((p) => p.team === team && !p.isGk);
}

export function tickHomeSoccerAI(players, ball, match, dt) {
  homeCpuPassCd = Math.max(0, homeCpuPassCd - dt);

  tickFormationAI(players, ball, TEAM_HOME, dt, { skipControlled: true });

  if (match.passSwitchToId != null) {
    const recv = players.find((p) => p.id === match.passSwitchToId);
    if (recv && !recv.controlled) chaseBall(recv, ball, dt, 1.6);
    return;
  }

  const ballCarrier = ball.possessionId != null
    ? players.find((pl) => pl.id === ball.possessionId)
    : null;
  if (isBallDribbling(ball) && ballCarrier?.controlled) return;

  const cpu = outfield(players, TEAM_HOME).filter((p) => !p.controlled);
  let carrier = null;
  let d = Infinity;
  cpu.forEach((p) => {
    const dd = Math.hypot(p.x - ball.x, p.y - ball.y);
    if (dd < d) {
      d = dd;
      carrier = p;
    }
  });

  if (!carrier || d > 1.6 || ballSpeed(ball) > 2.8 || homeCpuPassCd > 0) return;

  const sign = attackingSign(TEAM_HOME);
  const mates = cpu.filter((m) => m.id !== carrier.id);
  const human = players.find((p) => p.team === TEAM_HOME && p.controlled);

  if (human && human.id !== carrier.id && d < 1.3) {
    kickBall(ball, human.x - carrier.x, human.y - carrier.y, 11, { lift: 0.2 });
    match.lastTouchTeam = TEAM_HOME;
    match.passSwitchToId = human.id;
    homeCpuPassCd = 0.8;
    return;
  }

  const target = mates.sort((a, b) => sign * (b.y - a.y))[0];
  if (target && Math.hypot(target.x - carrier.x, target.y - carrier.y) > 7) {
    kickBall(ball, target.x - carrier.x, target.y - carrier.y, 10, { lift: 0 });
    match.lastTouchTeam = TEAM_HOME;
    homeCpuPassCd = 1.2;
  }
}

export function tickAwaySoccerAI(players, ball, match, dt) {
  awayKickCd = Math.max(0, awayKickCd - dt);

  tickFormationAI(players, ball, TEAM_AWAY, dt, { skipControlled: true });

  const carrier = ball.possessionId != null
    ? players.find((pl) => pl.id === ball.possessionId)
    : null;
  if (isBallDribbling(ball) && carrier?.team === TEAM_HOME) return;

  const reds = outfield(players, TEAM_AWAY);
  const chaser =
    isBallDribbling(ball) && carrier?.team === TEAM_AWAY
      ? carrier
      : nearestToBall(reds, TEAM_AWAY, ball);
  if (!chaser) return;

  const dist = Math.hypot(chaser.x - ball.x, chaser.y - ball.y);
  if (dist > 1.6 || ballSpeed(ball) > 2.4 || awayKickCd > 0) return;

  const act = aiKickDecision(
    chaser,
    ball,
    reds,
    players.filter((p) => p.team === TEAM_HOME)
  );
  if (!act) return;

  awayKickCd = 0.65;
  const sign = attackingSign(TEAM_AWAY);
  if (act.type === 'shoot') {
    const fx = Math.cos(chaser.facing) * 0.35;
    const fy = Math.sin(chaser.facing) * 0.35 + sign * 0.65;
    const fl = Math.hypot(fx, fy) || 1;
    kickBall(ball, fx / fl, fy / fl, act.power, { lift: act.lift ?? 2.8 });
  } else if (act.target) {
    kickBall(
      ball,
      act.target.x - chaser.x,
      act.target.y - chaser.y,
      act.power,
      { lift: act.lift ?? 0.4 }
    );
  }
  match.lastTouchTeam = TEAM_AWAY;
}
